#include "stdafx.h"
#include "Character.h"
#include<iostream>

Character::Character()
{
	this->gender = MALE;
	sf::String fileName = "../Resources/player1.png";
	if (gender == MALE)
		fileName = "../Resources/player2.png";
	else if (gender == FEMALE)
		fileName = "../Resources/player1.png";

	if (!mTexture.loadFromFile(fileName))
	{
		// Handle error: Print error message.
		std::cout << "ERROR: Player image could not be loaded.\n---" << std::endl;
	}
	this->font.loadFromFile("../Resources/BEBAS___.ttf");
	this->mName.setFont(font);
	this->name = "HUH";
	this->mName.setString(this->name);
	this->mName.setCharacterSize(20);
	this->mName.setPosition(sf::Vector2f(0.0f, 0.0f));
	this->mSpriteSheet.setTexture(mTexture);
	this->mSpriteSheet.setTextureRect(sf::IntRect(0, 0, 32, 32));

	// Initialise animation variables.
	this->mCurrentKeyFrame = sf::Vector2i(0, 0);
	this->mKeyFrameSize = sf::Vector2i(32, 32);
	this->mSpriteSheetWidth = 4;
	this->mAnimationSpeed = 0.1f;
	this->mKeyFrameDuration = 0.0f;

	
	
	this->exp = 0;
	this->hp = 100;
	this->power=1;


}

Character::~Character()
{
}

void Character::Update(float dt)
{
	sf::Vector2f direction(0.0f, 0.0f);

	// Handle input from arrow keys and update direction and animation
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
	{
		if (this->mSpriteSheet.getPosition().x >= 0) {
			direction.x = -1.0f;
			mKeyFrameDuration += dt;
			mCurrentKeyFrame.y = 1;
		}
		cout << "X: " << mSpriteSheet.getPosition().x << endl;
		cout << "y: " << mSpriteSheet.getPosition().y << endl;
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
	{
		if (this->mSpriteSheet.getPosition().x <= 580 && this->mSpriteSheet.getPosition().y >= -2 && this->mSpriteSheet.getPosition().x <= 816 || this->mSpriteSheet.getPosition().x >= 580 && this->mSpriteSheet.getPosition().y >= 143 && this->mSpriteSheet.getPosition().x <= 816){
			direction.x = 1.0f;
			mKeyFrameDuration += dt;
			mCurrentKeyFrame.y = 2;
		}
		cout << "X: " << mSpriteSheet.getPosition().x << endl;
		cout << "y: " << mSpriteSheet.getPosition().y << endl;
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
	{
		if (this->mSpriteSheet.getPosition().y <= 444) {
			direction.y = 1.0f;
			mKeyFrameDuration += dt;
			mCurrentKeyFrame.y = 0;
		}
		cout << "X: " << mSpriteSheet.getPosition().x << endl;
		cout << "y: " << mSpriteSheet.getPosition().y << endl;
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) )
	{
		if (this->mSpriteSheet.getPosition().y >= 0 && this->mSpriteSheet.getPosition().x<=582 || this->mSpriteSheet.getPosition().y >= 145 && this->mSpriteSheet.getPosition().x >= 580) {
			direction.y = -1.0f;
			mKeyFrameDuration += dt;
			mCurrentKeyFrame.y = 3;
		}
		cout << "X: " << mSpriteSheet.getPosition().x << endl;
		cout << "y: " << mSpriteSheet.getPosition().y << endl;
	}
	
		mSpriteSheet.move(direction * mSpeed * dt);
	
	// Update animation
	if (mKeyFrameDuration >= mAnimationSpeed)
	{
		mCurrentKeyFrame.x++;

		if (mCurrentKeyFrame.x >= mSpriteSheetWidth)
			mCurrentKeyFrame.x = 0;

		mSpriteSheet.setTextureRect(sf::IntRect(mCurrentKeyFrame.x * mKeyFrameSize.x,
			mCurrentKeyFrame.y * mKeyFrameSize.y, mKeyFrameSize.x, mKeyFrameSize.y));
		mKeyFrameDuration = 0.0f;
	}

	this->mName.setPosition(sf::Vector2f(this->mSpriteSheet.getPosition().x, this->mSpriteSheet.getPosition().y-30));

}

void Character::draw(sf::RenderTarget & target, sf::RenderStates states) const
{
	target.draw(this->mName, states);
	target.draw(this->mSpriteSheet, states);
}
