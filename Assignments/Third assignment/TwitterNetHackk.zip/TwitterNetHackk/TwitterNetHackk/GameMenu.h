#ifndef GMENU_H
#define GMENU_H


#include "SFML/Graphics.hpp"
#include<SFML/Audio.hpp>



#define MAX_NUMBER_OF_ITMES 3
class GameMenu : public sf::Drawable
{

private:


	int choosenInMenu;
	int selectedItemIndex;
	sf::Font font;
	sf::Text menu[MAX_NUMBER_OF_ITMES];

	
	sf::Texture menuBackground;
	sf::Sprite menuB;
public:
	GameMenu(float width = 543, float height = 768);
	
	~GameMenu();

	int Update();
	int getPressedItem() { return selectedItemIndex; }
	void moveUp();
	void moveDown();

	void draw(sf::RenderTarget & target, sf::RenderStates states) const;
};

#endif