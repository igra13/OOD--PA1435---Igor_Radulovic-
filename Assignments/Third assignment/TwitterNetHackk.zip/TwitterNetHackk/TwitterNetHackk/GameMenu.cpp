#include "stdafx.h"
#include "GameMenu.h"




GameMenu::GameMenu(float width, float height)
{


	this->font.loadFromFile("../Resources/BEBAS___.ttf");
	//handle error

	this->choosenInMenu = -2;


	this->menu[0].setFont(font);
	this->menu[0].setFillColor(sf::Color::White);
	this->menu[0].setString("Create Game");
	this->menu[0].setPosition(sf::Vector2f(width / 8, height / (MAX_NUMBER_OF_ITMES) * 1));


	this->menu[1].setFont(font);
	this->menu[1].setFillColor(sf::Color::Blue);
	this->menu[1].setCharacterSize(60);
	this->menu[1].setString("Join Game");
	this->menu[1].setPosition(sf::Vector2f(width / 8, height / (MAX_NUMBER_OF_ITMES) * 1.5));

	this->menu[2].setFont(font);
	this->menu[2].setFillColor(sf::Color::White);
	this->menu[2].setString("Create Character");
	this->menu[2].setPosition(sf::Vector2f(width / 8, height / (MAX_NUMBER_OF_ITMES) * 2));

	this->selectedItemIndex = 1;



	this->menuBackground.loadFromFile("../Resources/menuBB.png");
	this->menuB.setTexture(menuBackground);





}

GameMenu::~GameMenu()
{
}

int GameMenu::Update()
{




	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
		this->moveUp();

	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
		this->moveDown();


	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return)) {

		this->choosenInMenu = this->selectedItemIndex;


	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape) ) {
		this->choosenInMenu = -1;
	}

	return this->choosenInMenu;
}



void GameMenu::draw(sf::RenderTarget & target, sf::RenderStates states) const
{

	target.draw(this->menuB,states);

	for (int i = 0; i < MAX_NUMBER_OF_ITMES; i++) {
		target.draw(this->menu[i], states);
	}





}

void GameMenu::moveUp()
{
	if (selectedItemIndex - 1 >= 0) {
		menu[selectedItemIndex].setFillColor(sf::Color::White);
		menu[selectedItemIndex].setCharacterSize(40);
		selectedItemIndex--;
		menu[selectedItemIndex].setFillColor(sf::Color::Blue);
		menu[selectedItemIndex].setCharacterSize(60);
	}
}

void GameMenu::moveDown()
{
	if (selectedItemIndex + 1 < MAX_NUMBER_OF_ITMES) {
		menu[selectedItemIndex].setFillColor(sf::Color::White);
		menu[selectedItemIndex].setCharacterSize(40);
		selectedItemIndex++;
		menu[selectedItemIndex].setFillColor(sf::Color::Blue);
		menu[selectedItemIndex].setCharacterSize(60);
	}
}
