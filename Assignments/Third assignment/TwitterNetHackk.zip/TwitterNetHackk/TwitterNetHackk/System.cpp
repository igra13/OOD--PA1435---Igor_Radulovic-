#include "stdafx.h"
#include "System.h"


void System::draw(sf::RenderTarget & target, sf::RenderStates states) const
{
	
	
	if (this->check != -1 && this->check != 0) {
		menu->draw(target, states);
		
	}
	
	else if(this->check==0){
		target.draw(mBackgroundSprite, states);
		target.draw(mCaveSprite, states);
		target.draw(mCharacter, states);
	}
	
}

System::System()
{
	if (!mBackgroundTex.loadFromFile("../Resources/background.jpg"))
	{
		
		std::cout << "ERROR: Background image could not be loaded.\n---" << std::endl;
	}
	if (!mCave.loadFromFile("../Resources/cave.png"))
	{
		
		std::cout << "ERROR: Cave image could not be loaded.\n---" << std::endl;
	}
	mCaveSprite.setTexture(mCave);
	mCaveSprite.setPosition(sf::Vector2f(600, 0));
	mBackgroundSprite.setTexture(mBackgroundTex);
	mBackgroundSprite.setScale(1.5, 1.5);
	this->check = -2;

	this->menu =new GameMenu(564*1.5, 316*1.5);
}


System::~System()
{
}

int System::Update(float dt)
{
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape)) {
		this->check = -1;
		
	}
	
	if(check!=0 && check !=-1)
		check = menu->Update();
	
	else {
		if (check == 0 && this->menu != nullptr || check == -1 && this->menu!=nullptr) {
			
			delete this->menu;
			this->menu = nullptr;
		}

		mCharacter.Update(dt);
	}
	return check;
}