// TwitterNetHackk.cpp : Defines the entry point for the console application.
//
#include <SFML/Graphics.hpp>
#include<iostream>
#include<SFML/Audio.hpp>
#include<vector>
#include<crtdbg.h>
#include "stdafx.h"
#include"System.h"
#include"GameMenu.h"
#include<ctime>
#include<time.h>

using namespace std;

int main()
{


	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	srand(time(NULL));

	//sf::RenderWindow menuWindow(sf::VideoMode(500, 500), "TwitterNetHack", sf::Style::Titlebar | sf::Style::Close);
	//sf::Clock gameTime;
	//
	//GameMenu menu(500,500);
	//int check = -1;
	//

	//while (menuWindow.isOpen()) {
	//	sf::Event menuEvent;

	//	while (menuWindow.pollEvent(menuEvent)) {
	//		if (menuEvent.type == sf::Event::Closed) {
	//			menuWindow.close();
	//		}

	//		check = menu.Update();

	//		if (check == 0) {
	//			menuWindow.close();
	//		}
	//		else if (check == 1) {

	//		}
	//		else if (check == 2) {
	//			menuWindow.close();
	//		}

	//	}




	//	menuWindow.clear();

	//	menuWindow.draw(menu);

	//	menuWindow.display();



	//}

	/*if (check == 0) {*/
		sf::RenderWindow window(sf::VideoMode(1.5 * 564, 1.5 * 316), "TwitterNetHack");
		System sys;
		sf::Clock gameTime;
		int check2=0;
		if (check2 != -1) {
			while (window.isOpen())
			{
				sf::Event event;
				while (window.pollEvent(event))
				{
					if (event.type == sf::Event::Closed)
						window.close();

				}
				if (check2 == -1) {
					window.close();
				}
				// Update()
				check2 = sys.Update(gameTime.restart().asSeconds());

				// Draw()
				window.clear();
				window.draw(sys);
				window.display();
			}
		}
		
	//}
	




    return 0;

	
}

