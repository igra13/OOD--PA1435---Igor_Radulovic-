#ifndef CHAR_H
#define CHAR_H
#include <SFML/Graphics.hpp>
#include<iostream>
#include<SFML/Audio.hpp>
#include<vector>
#include<crtdbg.h>
#include "stdafx.h"
#include<string>
using namespace std;



class Character : public sf::Drawable {

private:
	enum Gender { MALE, FEMALE };
	sf::Texture mTexture;
	sf::Sprite mSpriteSheet;
	sf::Text mName;
	sf::Font font;
	float mSpeed = 150.0f;

	// Animation variables
	sf::Vector2i mCurrentKeyFrame;
	sf::Vector2i mKeyFrameSize;
	int mSpriteSheetWidth;
	float mAnimationSpeed;
	float mKeyFrameDuration;



	string name;
	Gender gender;
	int exp;
	int hp;
	int power;
public:

	Character();
	~Character();

	void Update(float dt);


	void draw(sf::RenderTarget &target, sf::RenderStates states) const;



};





#endif // !CHAR_H

