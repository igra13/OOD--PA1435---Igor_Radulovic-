#ifndef SYS_H
#define SYS_H
#include"Character.h"
#include"GameMenu.h"
class System : public sf::Drawable
{
private:
	sf::Texture mBackgroundTex;
	sf::Sprite mBackgroundSprite;
	sf::Texture mCave;
	sf::Sprite mCaveSprite;
	Character mCharacter;
	GameMenu  *menu;
	void draw(sf::RenderTarget &target, sf::RenderStates states) const;
	int check = -2;
	int counter = 0;
	int check2 = 0;
public:
	System();
	~System();
	int Update(float dt);
};

#endif