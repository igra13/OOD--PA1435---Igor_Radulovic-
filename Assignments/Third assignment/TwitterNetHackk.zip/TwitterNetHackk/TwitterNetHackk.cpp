// TwitterNetHackk.cpp : Defines the entry point for the console application.
//
#include <SFML/Graphics.hpp>
#include<iostream>
#include<SFML/Audio.hpp>
#include<vector>
#include<crtdbg.h>
#include "stdafx.h"
#include"System.h"

using namespace std;

int main()
{
	sf::RenderWindow window(sf::VideoMode(600, 600), "Game Window");
	System sys;
	sf::Clock gameTime;

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}

		// Update()
		sys.Update(gameTime.restart().asSeconds());

		// Draw()
		window.clear();
		window.draw(sys);
		window.display();
	}




    return 0;

	
}

