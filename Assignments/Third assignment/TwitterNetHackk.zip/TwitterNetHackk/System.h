#ifndef SYS_H
#define SYS_H
#include"Character.h"
class System : public sf::Drawable
{
private:
	sf::Texture mBackgroundTex;
	sf::Sprite mBackgroundSprite;
	Character mCharacter;

	void draw(sf::RenderTarget &target, sf::RenderStates states) const;

public:
	System();
	~System();
	void Update(float dt);
};

#endif