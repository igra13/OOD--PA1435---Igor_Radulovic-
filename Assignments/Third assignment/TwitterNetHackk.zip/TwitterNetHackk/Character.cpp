#include "stdafx.h"
#include "Character.h"

Character::Character()
{
	sf::String fileName = "../Resources/player1.png";
	if (gender == MALE)
		fileName = "../Resources/player1.png";
	else if (gender == FEMALE)
		fileName = "../Resources/player2.png";

	if (!mTexture.loadFromFile(fileName))
	{
		// Handle error: Print error message.
		std::cout << "ERROR: Player image could not be loaded.\n---" << std::endl;
	}

	this->mSpriteSheet.setTexture(mTexture);
	this->mSpriteSheet.setTextureRect(sf::IntRect(0, 0, 32, 32));

	// Initialise animation variables.
	this->mCurrentKeyFrame = sf::Vector2i(0, 0);
	this->mKeyFrameSize = sf::Vector2i(32, 32);
	this->mSpriteSheetWidth = 4;
	this->mAnimationSpeed = 0.2f;
	this->mKeyFrameDuration = 0.0f;

	this->name = "HUH";
	this->gender = MALE;
	this->exp = 0;
	this->hp = 100;
	this->power=1;


}

Character::~Character()
{
}

void Character::Update(float dt)
{
	sf::Vector2f direction(0.0f, 0.0f);

	// Handle input from arrow keys and update direction and animation
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
	{
		direction.x = -1.0f;
		mKeyFrameDuration += dt;
		mCurrentKeyFrame.y = 1;
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
	{
		direction.x = 1.0f;
		mKeyFrameDuration += dt;
		mCurrentKeyFrame.y = 2;
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
	{
		direction.y = 1.0f;
		mKeyFrameDuration += dt;
		mCurrentKeyFrame.y = 0;
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
	{
		direction.y = -1.0f;
		mKeyFrameDuration += dt;
		mCurrentKeyFrame.y = 3;
	}

	mSpriteSheet.move(direction * mSpeed * dt);

	// Update animation
	if (mKeyFrameDuration >= mAnimationSpeed)
	{
		mCurrentKeyFrame.x++;

		if (mCurrentKeyFrame.x >= mSpriteSheetWidth)
			mCurrentKeyFrame.x = 0;

		mSpriteSheet.setTextureRect(sf::IntRect(mCurrentKeyFrame.x * mKeyFrameSize.x,
			mCurrentKeyFrame.y * mKeyFrameSize.y, mKeyFrameSize.x, mKeyFrameSize.y));
		mKeyFrameDuration = 0.0f;
	}
}

void Character::draw(sf::RenderTarget & target, sf::RenderStates states) const
{
	target.draw(this->mSpriteSheet, states);
}
