#include "stdafx.h"
#include "System.h"


void System::draw(sf::RenderTarget & target, sf::RenderStates states) const
{
	// Make sure everything in the game is drawn.
	target.draw(mBackgroundSprite, states);
	target.draw(mCharacter, states);
}

System::System()
{
	if (!mBackgroundTex.loadFromFile("../Resources/background.jpg"))
	{
		// Handle error: Print error message.
		std::cout << "ERROR: Background image could not be loaded.\n---" << std::endl;
	}
	mBackgroundSprite.setTexture(mBackgroundTex);
}


System::~System()
{
}

void System::Update(float dt)
{
	// Make sure everything in the game is updated (if needed).
	mCharacter.Update(dt);
}